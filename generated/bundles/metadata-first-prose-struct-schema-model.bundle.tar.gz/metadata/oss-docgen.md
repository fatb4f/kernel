Your artifact is pushing toward a **transform-first** architecture: rooted sources → extracted units → normalized structural model → canonical document model → projections, with docgen kept intentionally “dumb” and projection-only. That framing matters, because it changes the comparison class from “which docs site generator is popular?” to “which OSS layers help build a metadata-backed document pipeline?” 

## What looks solid in OSS right now

The strongest established pattern is **docs as code with static publication**, not monolithic docgen. Backstage TechDocs explicitly treats docs as Markdown living with code, and its recommended architecture is to generate docs in CI/CD, store the built site externally, and keep the portal read-only at runtime. MkDocs remains a simple Markdown-to-static-docs foundation, while Docusaurus remains strong on versioning and search integration. ([backstage.io][1])

A second strong pattern is **typed content/data layers ahead of rendering**. Astro’s content collections define content by location and shape, support loaders, and allow schema validation for type safety; the newer Content Layer direction pushes further by loading data from many sources behind one type-safe API. Contentlayer is in the same family: it validates and transforms content into type-safe JSON that the app imports later. This is very close to your “canonical model first, projections second” direction. ([Astro Documentation][2])

A third mature area is **spec-driven generation**. OpenAPI Generator can generate documentation and related artifacts from an OpenAPI spec, and AsyncAPI Generator is even more explicit that one validated source plus a template can generate many outputs, including code, diagrams, Markdown, and apps. For metadata-backed docgen, this is the clearest OSS proof that multi-artifact projection from one structured source is already normal. ([GitHub][3])

A fourth established layer is **AST/pipeline-based document transforms**. MDX is built on a unified parsing/transformation pipeline, and Docusaurus exposes MDX plugins for remark/rehype transforms. That is important because it means projection-time rewrites, enrichment, and component insertion are already well-served by OSS. ([MDX][4])

A fifth solid area is **docs governance and quality gates**. Vale brings code-like linting to prose, and Diátaxis remains a widely used framework for separating tutorial/how-to/reference/explanation concerns. That does not solve metadata-backed consolidation, but it does solve quality control on the human-readable side. ([Vale][5])

## What is emerging

The clearest emerging direction is **content-layer architecture instead of renderer-first architecture**. Astro now supports both build-time and live-updating collections through loaders plus optional schemas, and its content-layer work is explicitly about mixing local files and remote sources behind one API. That is a strong signal that the ecosystem is moving toward “ingest structured content from anywhere, then render later.” ([Astro Documentation][2])

Another emerging direction is **hybrid static + live documentation data**. Astro’s live collections exist specifically for frequently changing sources that should not require full rebuilds, while still keeping the same collection API. That matters for metadata-backed docgen because it opens the door to a model where the canonical document stays deterministic for release artifacts, but selected indices or adjunct views can be refreshed from live sources. ([Astro Documentation][6])

Search is also becoming more **artifact-like and metadata-aware**. Pagefind runs after site generation, builds a static search bundle, supports filtering, sorting, metadata tracking, and section-level results, and Starlight uses it by default. Docusaurus, meanwhile, keeps first-class support for Algolia DocSearch. For your design, that suggests retrieval index generation should be treated as a projection target, not an afterthought. ([Pagefind][7])

There is also a noticeable shift in **innovation momentum**. My read is that new ideas are clustering around Astro/Starlight/content-layer-style systems, while Material for MkDocs has explicitly entered maintenance mode as of November 2025. That does not make MkDocs non-viable; it means the center of new experimentation appears to be moving toward typed content loaders and richer projection layers. ([GitHub Pages][8])

## What is still missing in OSS for your exact problem

I do **not** see a single dominant OSS project in these sources that natively gives you the whole chain you want:

* rooted source registry
* extracted structural units
* normalized canonical document object
* multiple deterministic projections with provenance

What exists today is strong **by layer**, not end-to-end: TechDocs for docs-in-repo publication, Astro/Contentlayer for typed content ingestion, CUE for schema/policy constraints, MDX/unified for transform pipelines, AsyncAPI/OpenAPI for spec-driven generation, and Pagefind/DocSearch for retrieval. The gap is the middle object your artifact identifies: a **first-class structural/consolidation model with stable refs and provenance at unit level**.  ([Astro Documentation][2])

That gap is also why mainstream docs stacks are not enough by themselves. Most of them assume that the authored page or collection entry is already the canonical unit. Astro collections are entry-shaped, Contentlayer transforms content into typed JSON, and Markdoc frontmatter is passed in as variables for rendering. None of that is the same as provenance-preserving paragraph/claim/policy/question extraction with stacked refs. ([Astro Documentation][2])

## Practical takeaway for your feature

For a metadata-backed docgen feature, the strongest OSS-aligned architecture is:

1. **Own the middle**
   Build your own `source_registry`, `structural_units`, and `canonical_document` objects.

2. **Borrow validation, not identity, from OSS**
   Use CUE or JSON Schema for admissibility and shape constraints, because CUE is explicitly built for data, schema, and policy constraints together. ([CUE][9])

3. **Keep projection dumb**
   Use MD/MDX/Markdoc renderers and site frameworks as projection layers, not as the source of truth. ([MDX][4])

4. **Generate search/index artifacts intentionally**
   Treat TOC, glossary, source map, retrieval index, and summary views as first-class projection outputs. Pagefind’s model maps well to that. ([Pagefind][7])

5. **Publish like TechDocs**
   Generate in CI, publish static/read-only artifacts, and avoid runtime mutation of canonical docs. ([backstage.io][10])

## Bottom line

**Current OSS trend:** typed content ingestion, schema validation, static publication, and post-build indexing are solid.
**Emerging trend:** content-layer architectures, live loaders, and multi-artifact projection from one structured model are gaining momentum.
**What is still custom work:** the provenance-rich intermediate model your artifact is already arguing for. 

The shortest accurate summary is: **the ecosystem is converging on “docs as validated data,” but your exact “rooted refs → structural units → canonical document → projections” stack is still a composition job, not a single off-the-shelf OSS product.**

If useful, I can turn this into a **design map of OSS building blocks vs. the stages in your proposed pipeline**.

[1]: https://backstage.io/docs/features/techdocs/ "TechDocs Documentation | Backstage Software Catalog and Developer Platform"
[2]: https://docs.astro.build/en/guides/content-collections/ "Content collections | Docs"
[3]: https://github.com/OpenAPITools/openapi-generator "GitHub - OpenAPITools/openapi-generator: OpenAPI Generator allows generation of API client libraries (SDK generation), server stubs, documentation and configuration automatically given an OpenAPI Spec (v2, v3) · GitHub"
[4]: https://mdxjs.com/packages/mdx/ "@mdx-js/mdx | MDX"
[5]: https://vale.sh/docs "Introduction - Vale CLI"
[6]: https://docs.astro.build/ar/reference/experimental-flags/live-content-collections/ "Content collections | Docs"
[7]: https://pagefind.app/ "Pagefind | Pagefind — Static low-bandwidth search at scale"
[8]: https://squidfunk.github.io/mkdocs-material/changelog/ "Changelog - Material for MkDocs"
[9]: https://cuelang.org/docs/ "Documentation | CUE"
[10]: https://backstage.io/docs/features/techdocs/how-to-guides/ "TechDocs How-To guides | Backstage Software Catalog and Developer Platform"
