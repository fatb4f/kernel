
• I’m treating this as a transform-design problem: start from the desired artifact shape, work backward to the minimal metadata and intermediate structure needed, and avoid inventing a docgen-only side channel.

• Whitebox Analysis

  Start from the constraint you already set:

  - desired output exists
  - docgen should be dumb
  - one hierarchical rooted ref system
  - no docgen-only metadata lane

  So the task is to define the minimum transform chain that can produce the desired output deterministically.

  Target

  The desired output appears to be a document artifact family like:

  - consolidated JSON
  - consolidated Markdown
  - summary JSON
  - summary Markdown

  With properties like:

  - stable section ids
  - stable ordering
  - normalized terms
  - source traceability
  - TOC/retrieval index
  - glossary
  - open questions
  - source map

  That means the transform must output a single canonical structured document model first, then project it.

  So the real transform is:

  rooted sources
  -> extracted source units
  -> normalized structural model
  -> canonical document model
  -> projections

  What docgen should do

  Only the last step:

  canonical document model
  -> consolidated.json
  -> consolidated.md
  -> summary.json
  -> summary.md

  That keeps docgen dumb.

  What the transform must do before docgen

  There are three real stages before projection.

  1. Rooted source resolution
     Input:

  - repo root
  - source refs under root

  Job:

  - resolve actual source documents
  - assign stable rooted refs
  - preserve parent/child hierarchy
  - avoid ambiguity between identity and location

  Output:

  - rooted source registry

  Example responsibilities:

  - scratch/problem_set.md is a source document under root
  - repo-control-plane.template.yaml is a schema/control document under root
  - each has one stable ref

  2. Structural extraction
     Input:

  - rooted source registry
  - source documents

  Job:

  - segment documents into meaningful units
  - identify candidate sections, claims, policies, terms, open questions
  - preserve provenance back to source refs
  - no normalization yet beyond segmentation and tagging

  Output:

  - extracted structural units

  This is where you derive things like:

  - “this paragraph is about authority”
  - “this subsection defines token burn”
  - “this note expresses an unresolved tension”

  3. Normalization / consolidation
     Input:

  - extracted structural units
  - ordering policy
  - section model derived from schema/template

  Job:

  - merge overlapping units
  - resolve preferred terminology
  - map content into canonical sections
  - preserve unresolved conflicts as open_questions
  - bind normalized terms
  - produce one canonical document object

  Output:

  - canonical document model

  This is the actual bridge from prose to struct to schema.

  Minimal transform contract

  If we work backward from the output, the canonical document model needs at least:

  {
    "document_id": "...",
    "version": "...",
    "title": "...",
    "summary": "...",
    "toc_index": [...],
    "sections": [...],
    "glossary": [...],
    "open_questions": [...],
    "source_map": [...]
  }

  So the transform must produce these objects deterministically.

  That means the upstream structural model must at least support:

  - source_node
  - structural_unit
  - normalized_section
  - normalized_term
  - open_question
  - projection_target

  Ref system needed for this transform

  Because you do not want dual-track metadata, refs must stack.

  Minimum pattern:

  1. root ref

  - anchors everything to repo root

  2. source ref

  - identifies a source artifact under root

  3. unit ref

  - identifies an extracted structural unit from a source

  4. section ref

  - identifies a normalized section assembled from units

  5. artifact ref

  - identifies a projected output artifact derived from sections

  That gives one chain:

  root
  -> source
  -> unit
  -> normalized section
  -> projected artifact

  Why the previous run drifted

  Because the transform appears to have jumped too quickly from:

  - source docs
    to
  - canonical document

  without making the intermediate structural layer first-class.

  That caused:

  - loose source refs
  - ambiguous glossary identities
  - section content that mostly normalized correctly
  - but metadata traceability that stayed fuzzy

  So the missing engineered object is not “better docgen”.
  It is the intermediate structural model.

  The transform you actually need

  Here is the likely minimal whitebox pipeline:

  1. Source registry build
     - collect rooted source refs
     - classify source kinds

  2. Structural extraction
     - split each source into units
     - assign unit refs
     - classify unit type:
       section_candidate
       policy_candidate
       term_candidate
       question_candidate
       source_note

  3. Section mapping
     - map units to canonical section ids
     - preserve provenance

  4. Consolidation
     - merge units by section
     - dedupe repeated concepts
     - choose preferred terms
     - surface unresolved tensions

  5. Canonical document assembly
     - build toc_index
     - build sections
     - build glossary
     - build open_questions
     - build source_map

  6. Projection
     - render full JSON
     - render full Markdown
     - render summary JSON
     - render summary Markdown

  What should be schema-backed

  Not just the output.

  Schema should exist for:

  1. source registry
  2. structural units
  3. canonical document model
  4. projected artifact manifest if needed

  That lets you validate each transform boundary instead of only validating the final document.

  Recommended engineering boundary

  - repo metadata owns:
      - rooted refs
      - source registry
      - structural units
      - normalized document model
  - docgen owns:
      - projection only

  That gives you:

  - one metadata system
  - one transform chain
  - one canonical document object
  - multiple dumb outputs

  Decision points to make explicit

  Before implementation, you need to lock:

  1. canonical section set

  - fixed from template/schema, or partially extensible?

  2. structural unit granularity

  - paragraph-level
  - heading-block-level
  - section-level

  3. normalization precedence

  - template/schema > normalized summary > scratch prose
  - or some other order

  4. glossary identity rule

  - glossary term ids must match normalized anchor ids exactly?

  5. open-question rule

  - what counts as unresolved enough to survive normalization?

  Bottom line

  The transform is:

  rooted sources
  -> extracted structural units
  -> normalized canonical document model
  -> dumb projections

  The missing engineered layer is:

  - extracted structural units with stacked refs

  That is the core bridge between prose and schema.

  If you want, next I can write the minimal data model for:

  1. source_registry.json
  2. structural_units.json
  3. canonical_document.json
