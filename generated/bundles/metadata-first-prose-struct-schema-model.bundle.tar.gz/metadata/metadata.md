## Metadata-first workflows

Across OSS, the recurring idea is the same: **metadata is the control plane**, while docs, catalogs, lineage, automation, validation, and runtime views are **derived projections**. You see this in Backstage catalog descriptors, Dagster asset definitions and observations, OpenLineage design-time and run-time events, and DataHub/OpenMetadata metadata catalogs and contracts. ([backstage.io][1])

### 1. Author → validate → register

A human or generator writes a descriptor, manifest, or asset definition; the system validates structure and semantics; then the object is registered into a catalog or graph. Backstage’s catalog descriptors are YAML/JSON with a defined structure, and catalog entities are identified by kind/namespace/name references. JSON Schema provides the baseline mechanisms for required fields and conditional dependencies. ([backstage.io][1])

### 2. Ingest → normalize → enrich

Raw metadata from source systems is pulled in, normalized into a common model, then enriched with ownership, tags, descriptions, lineage, or policy context. OpenMetadata documents ingestion from databases, pipelines, dashboards, and storage; its reporting emphasizes ownership, documentation, and tiering coverage. ([OpenMetadata Documentation][2])

### 3. Resolve references → build graph

Descriptors rarely stand alone. They reference owners, systems, datasets, upstream assets, or contracts. Backstage formalizes entity references; DataHub uses URNs as globally unique identifiers and models relationships as first-class metadata. ([backstage.io][3])

### 4. Project metadata into artifacts

The metadata object is not the final product; it drives generation of docs, catalog pages, views, alerts, scaffolds, configs, forms, or automation state. Backstage entities can feed TechDocs and catalog views, while Dagster asset definitions describe what should exist and how it is produced. ([backstage.io][4])

### 5. Reconcile desired metadata with observed reality

A metadata-first system usually has both a **declared state** and an **observed state**. Dagster explicitly separates asset observations from materializations, and OpenLineage distinguishes run/job/dataset events from design-time dataset metadata updates. ([Dagster Docs][5])

### 6. Verify contracts and policy

Once metadata is authoritative, you can attach machine-checkable guarantees. DataHub’s contracts and assertions cover schema, freshness, and quality; schema assertions explicitly detect column/type drift. ([docs.datahub.com][6])

### 7. Publish lineage and events

Metadata changes and runtime events are emitted to other systems so downstream tools can react. OpenLineage exposes an API for job/run/dataset events and uses extensible facets to carry additional metadata. ([openlineage.io][7])

---

## Common patterns

### Manifest/descriptor-first

A YAML or JSON file is the canonical declaration, edited by humans or generators, then validated and ingested. Backstage is the clearest example. ([backstage.io][1])

### Schema-first

The allowed shape is defined before runtime usage. JSON Schema is the common baseline for required fields, typing, and conditional constraints. ([json-schema.org][8])

### Graph-first

Entities are valuable because of their relationships, not just their fields. Backstage entity refs and DataHub URNs/relationships both push toward graph semantics. ([backstage.io][3])

### Projection-first

The source object stays small and canonical; docs, indexes, inventories, forms, search views, and automation payloads are derived. This is how catalog systems and asset systems stay composable. ([backstage.io][9])

### Facet/aspect extension

The core model stays stable while extension points hold domain-specific metadata. OpenLineage facets and DataHub aspects/entities both use this pattern. ([openlineage.io][10])

### Desired-vs-observed split

Keep spec metadata separate from runtime facts. Dagster observations and OpenLineage dataset metadata updates make this distinction explicit. ([Dagster Docs][5])

### Contract-attached metadata

Metadata is not just descriptive; it becomes enforceable through assertions, schema checks, freshness rules, and promotion gates. DataHub documents this directly. ([docs.datahub.com][6])

### Ingestion plus curation

The system accepts automated ingestion, but curated metadata like ownership, descriptions, and tiering is still necessary for trust and discoverability. OpenMetadata’s ingestion and insights flows reflect that balance. ([OpenMetadata Documentation][2])

---

## Required invariants

These are the invariants that keep metadata-first systems from collapsing into drift and ambiguity.

### Identity invariants

Every object needs a **stable, unique, canonical identity**. Backstage uses entity references built from kind/namespace/name; DataHub uses URNs. Without this, merges, joins, lineage, and ownership all become unreliable. ([backstage.io][3])

### Shape invariants

Every object needs a **versioned schema** with required fields and explicit conditional rules. JSON Schema’s `required` and `dependentRequired` illustrate the baseline expectation. ([JSON Schema Tour][11])

### Reference invariants

All cross-object references must resolve deterministically to valid targets. Broken or ambiguous refs are not minor errors; they break the graph. Backstage and DataHub both model explicit cross-entity references. ([backstage.io][3])

### Authority invariants

For each field, there must be one clear authority: source system, generated projection, or human curation. OSS catalogs show this by separating ingestion from curated metadata and by distinguishing entity descriptors from external providers. ([backstage.io][12])

### Determinism invariants

Given the same metadata input, the same projection should be produced. Otherwise review, diffing, caching, and promotion are unstable. This is an inference from descriptor-based and asset-definition-based systems, where the declaration is intended to be the repeatable source of truth. ([backstage.io][1])

### Idempotence invariants

Re-applying the same metadata should converge, not duplicate or fork state. Backstage explicitly skips duplicate discovered entities with the same `metadata.name` in conflict scenarios, which reflects the need for convergence behavior. ([backstage.io][13])

### Separation-of-concerns invariants

Design-time declarations, runtime observations, and quality/policy results should not be conflated. OpenLineage separates dataset metadata updates from runs, and Dagster separates observations from materializations. ([openlineage.io][14])

### Provenance invariants

Every important metadata value should carry source/provenance: who set it, from where, and when. DataHub’s model includes system- or user-applied metadata context, and lineage/event systems encode who/when for events. ([openlineage.io][10])

### Compatibility invariants

Changes must be classified as additive, compatible, or breaking. This matters especially for schema, refs, ownership semantics, and contracts. DataHub’s schema assertions and contracts operationalize this for data assets. ([docs.datahub.com][6])

### Completeness invariants

Metadata-first only works if the minimum required fields for routing and governance are actually present: identity, owner, type, lifecycle/status, and relevant refs. OpenMetadata’s reporting on ownership and description coverage is a sign that completeness itself must be measured. ([OpenMetadata Documentation][15])

---

## Minimal practical set

For a metadata-backed docgen or control-plane workflow, the minimum useful invariant set is:

1. **Canonical ID**
2. **Schema version**
3. **Explicit owner/authority**
4. **Resolvable references**
5. **Deterministic projection**
6. **Observed vs desired separation**
7. **Provenance**
8. **Compatibility checks before promotion**

That combination is what turns metadata from “extra fields” into a real control surface. It is the common thread across catalog, lineage, orchestration, and contract systems in OSS today. ([backstage.io][1])

## Useful shorthand

A compact mental model:

**Declare → validate → resolve → project → reconcile → verify → publish**

That sequence matches the way Backstage, Dagster, OpenLineage, OpenMetadata, and DataHub each treat metadata as operational state instead of passive annotation. ([backstage.io][1])

I can also turn this into a **workflow matrix for docgen specifically** with columns for `object`, `authority`, `projection`, `gate`, and `promotion evidence`.

[1]: https://backstage.io/docs/features/software-catalog/descriptor-format/?utm_source=chatgpt.com "Descriptor Format of Catalog Entities - Backstage"
[2]: https://docs.open-metadata.org/v1.12.x/how-to-guides/admin-guide/how-to-ingest-metadata?utm_source=chatgpt.com "How to Ingest Metadata | Official Documentation"
[3]: https://backstage.io/docs/features/software-catalog/references/?utm_source=chatgpt.com "Entity References - Software Catalog - Backstage"
[4]: https://backstage.io/docs/features/techdocs/how-to-guides/?utm_source=chatgpt.com "TechDocs How-To guides | Backstage Software Catalog and ..."
[5]: https://docs.dagster.io/guides/build/assets/metadata-and-tags/asset-observations?utm_source=chatgpt.com "Asset observations"
[6]: https://docs.datahub.com/docs/managed-datahub/observe/data-contract?utm_source=chatgpt.com "Data Contracts"
[7]: https://openlineage.io/apidocs/openapi/?utm_source=chatgpt.com "OpenLineage API Docs"
[8]: https://json-schema.org/understanding-json-schema/reference/object?utm_source=chatgpt.com "object"
[9]: https://backstage.io/docs/features/software-catalog/software-catalog-api/?utm_source=chatgpt.com "API | Backstage Software Catalog and Developer Platform"
[10]: https://openlineage.io/docs/spec/facets/?utm_source=chatgpt.com "Facets & Extensibility"
[11]: https://tour.json-schema.org/content/01-Getting-Started/03-Required-Properties?utm_source=chatgpt.com "Required Properties: Getting Started"
[12]: https://backstage.io/docs/features/software-catalog/external-integrations/?utm_source=chatgpt.com "External integrations - Software Catalog - Backstage"
[13]: https://backstage.io/docs/features/software-catalog/configuration/?utm_source=chatgpt.com "Catalog Configuration | Backstage Software Catalog and ..."
[14]: https://openlineage.io/docs/1.41.0/spec/object-model/?utm_source=chatgpt.com "Object Model"
[15]: https://docs.open-metadata.org/v1.12.x/how-to-guides/data-insights/report?utm_source=chatgpt.com "Data Insights Report | OpenMetadata Reporting Guide"
